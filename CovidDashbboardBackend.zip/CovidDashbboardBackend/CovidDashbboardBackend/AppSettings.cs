﻿namespace CovidDashbboardBackend
{
    public class AppSettings
    {
        public string? Secret { get; set; }

    }
}
