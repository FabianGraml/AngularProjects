﻿namespace CovidDashbboardBackend.DTOs
{
    public class CovidGenderCasesDTO
    {
        public int MaleCases { get; set; }
        public int FemaleCases { get; set; }
    }
}
