﻿namespace CovidDashbboardBackend.DTOs
{
    public class CovidDeathsDTO
    {
        public string? Date { get; set; }
        public string? Country { get; set; }
        public string? Deaths { get; set; }


    }
}
