﻿namespace CovidDashbboardBackend.Models
{
    public class CovidCasesTimeline
    {
        public string? Date { get; set; }
        public string? Country { get; set; }
        public string? NewCases { get; set; }
        public string? Deaths { get; set; }

    }
}
